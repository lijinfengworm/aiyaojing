<?php
/**
 * Created by PhpStorm.
 * User: li
 * Date: 3/4/16
 * Time: 2:34 PM
 */
$config = array();
define('STATIC_PATH','/static/');
define('CDN_ADDRESS', 'http://admin.aiyaojing.com/');