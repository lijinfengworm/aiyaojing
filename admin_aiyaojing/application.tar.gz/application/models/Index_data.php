<?php
/**
 * Created by PhpStorm.
 * User: li
 * Date: 3/5/16
 * Time: 3:07 PM
 */

class Index_data extends MY_Model {
    function __construct(){
        parent::__construct();
    }
    const AUTH = 'auth';
    const ADMIN_USER = 'admin_user';


}