#__author__ = 'worm'
# coding=gbk
print("12312")